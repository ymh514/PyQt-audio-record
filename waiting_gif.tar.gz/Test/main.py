from PyQt5 import QtGui, QtCore,QtWidgets

class Window(QtWidgets.QWidget):
    def __init__(self):
        QtWidgets.QWidget.__init__(self)

        self.movie = QtGui.QMovie("wait.gif",QtCore.QByteArray(),self)
        size = self.movie.scaledSize()
        self.movie.setCacheMode(QtGui.QMovie.CacheAll)
        self.movie.setSpeed(100)

        self.b2 = QtWidgets.QPushButton()
        self.movie_screen = QtWidgets.QLabel()
        # Make label fit the gif
        self.movie_screen.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)

        # Create the layout
        main_layout = QtWidgets.QVBoxLayout()
        main_layout.addWidget(self.movie_screen)

        self.setLayout(main_layout)

        self.movie.setCacheMode(QtGui.QMovie.CacheAll)
        self.movie.setSpeed(100)
        self.movie_screen.setMovie(self.movie)

        self.movie.start()



if __name__ == '__main__':

    import sys
    app = QtWidgets.QApplication(sys.argv)
    window = Window()
    window.show()
    sys.exit(app.exec_())